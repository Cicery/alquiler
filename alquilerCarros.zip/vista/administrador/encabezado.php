
<img width="100%" height="35%" src="../../recursos/imagenes/encabezado.jpg">
