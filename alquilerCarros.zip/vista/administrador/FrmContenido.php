<div style="margin-left: 200px">
<div align="center">
    <h1>ADMINISTRADOR</h1>
</div>
<div>
    <p >Funciones: </p>
    <p>Agregar empleados al sistema </p>
    <p>Actualizar empleados </p>
    <p>Listar empleados registrados </p>
</div>
    <div align="center"><img src="../../recursos/imagenes/automovil.jpg" align="center" width="30%" height="auto"></div>

</div>