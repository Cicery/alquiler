
<div style="margin-left: 200px">
  <h1>Binevenido Asistente</h1>
  <div>
    <p>la aplicacion puede hacer las sigientes tareas:</p>
    <p> -agregar clientes</p>
    <p>-agregar alquiler</p>
    <div align="center"><img src="../../recursos/imagenes/automovil.jpg" align="center"></div>
    <p>&nbsp; </p>
  </div>

</div>