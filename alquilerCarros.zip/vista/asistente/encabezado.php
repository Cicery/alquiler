<img width="100%" height="75%" src="../../recursos/imagenes/encabezado.jpg">
